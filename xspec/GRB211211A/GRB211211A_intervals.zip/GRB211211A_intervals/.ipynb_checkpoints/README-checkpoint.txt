ASIM T0 = '2021-12-11T13:10:03.113' UTC
ASIM shifted into FERMI ref. frame
ASIM background accumulated 80 s after ASIM T0. Background countrate for this magnetic latitude within expected range


FERMI T0 = '2021-12-11 13:09:59.651' UTC
FERMI background accumulated on this interval: [(-100.0, -50.0), (150,200)] [s] with respect to FERMI T0


New intervals for spectrum [s]:

I = [[1.5, 2.5],
     [2.5, 3.5], 
     [3.5, 4.5], 
     [5.5, 6.5],
     [6.8, 7.25], 
     [7.25,7.55],
     [7.65, 7.9]]
     
See attached LC with highlighted intervals of ASIM and FERMI
     
Fits files for each interval found in sub folders with the pattern i_*

joint_fit.xcm files produced for i_5 and i_6
